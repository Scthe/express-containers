export const isatty = function () {
  return false;
};
