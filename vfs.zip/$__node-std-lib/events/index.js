export * from 'browserify-events';

// default export
// import * as name1 from 'browserify-events';
import name1 from 'browserify-events';
export default name1;
