export const homedir = '/home'; // check if this causes problems?

export default { homedir };
