// const util = require('./util');

// import * as util from './util';
// export * from './util';
// export const util;

export * from './util0';

// default export
import * as name1 from './util0';
export default name1;
