const name1 = {};
export default name1;
