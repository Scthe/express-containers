export * from 'browserify-stream';

// default export
import name1 from 'browserify-stream';
export default name1;
